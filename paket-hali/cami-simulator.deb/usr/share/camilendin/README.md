# cami-simulator V1.0.1
*kur-an kursundan sonra boks maçı yapmayan bizden değildir agaa* <br>
**ŞUANLIK SADECE BELIRLI DEĞERLER VEREN VE ÇOK BASİT AMAÇLA YAPILMIŞ BİR PROGRAM İDİR.**<br>
**İLERLİYEN SÜRÜMLERDE DAHA KEYİF VERİCİ BİR PROGRAM YAPMAK DİLEĞİYLE.**<br>
<br>
can sıkıntısından eğlence amaçlı yapılmış bir program idir.<br>
**DC**: leri#3131 <br>
**GEL AGA**: https://discord.gg/hF3EFWPFmk

# Kullanma
git clone https://github.com/LowLeery/cami_simulator.git <br>
cd cami-simulator <br>
bash camilendin.sh

















